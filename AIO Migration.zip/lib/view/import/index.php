<div class="ai1wm-container">
	<div class="ai1wm-row">
		<div class="ai1wm-left">
			<div class="ai1wm-holder">
				<h1>
					<img src="https://cdn-icons-png.flaticon.com/512/3648/3648517.png" height="40px" width="40px">
					<?php _e( 'Import Your Full Website', AI1WM_PLUGIN_NAME ); ?>
				</h1>

				<?php include AI1WM_TEMPLATES_PATH . '/common/report-problem.php'; ?>

				<form action="" method="post" id="ai1wm-import-form" class="ai1wm-clear" enctype="multipart/form-data">

					<p>
						<?php _e( 'File Size Increased By Adnan Habib', AI1WM_PLUGIN_NAME ); ?><br />
					</p>

					<?php do_action( 'ai1wm_import_left_options' ); ?>

					<?php include AI1WM_TEMPLATES_PATH . '/import/import-buttons.php'; ?>

					<input type="hidden" name="ai1wm_manual_import" value="1" />

				</form>

				<?php do_action( 'ai1wm_import_left_end' ); ?>

			</div>
		</div>
		<div class="ai1wm-right">
			<div class="ai1wm-sidebar">
				<div class="ai1wm-segment">
					<?php if ( ! AI1WM_DEBUG ) : ?>
						<?php include AI1WM_TEMPLATES_PATH . '/common/share-buttons.php'; ?>
					<?php endif; ?>

					

					<?php include AI1WM_TEMPLATES_PATH . '/common/leave-feedback.php'; ?>
				</div>
			</div>
		</div>
	</div>
</div>
