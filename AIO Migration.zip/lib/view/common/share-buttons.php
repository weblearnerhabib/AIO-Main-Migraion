<?php

?>

<div id="fb-root"></div>
<div class="ai1wm-share-button-container">
	<h2> This Plugin Made For Personal Use only </h2>
	<h1 style="color: #ff0faa; font-family: sans-serif; text-shadow: 3px 3px 6px #efff05;"> Adnan Habib </h1>
</div>
