<?php

?>

<a href="https://github.com/csehabiburr183" target="_blank"><?php _e( 'Get in Touch Plugin Cracker', AI1WM_PLUGIN_NAME ); ?></a>
