<?php
/**
 * Plugin Name: Migrate Site By Adnan Habib
 * Plugin URI: https://freelancer.com/u/csehabiburr183
 * Description: Import or Export your blog content with a single click Via Google Drive.
 * Author: Adnan Habib
 * Author URI: https://youtube.com/@adnanhabib
 * Version: 1.0.1 Init
 * Text Domain: all-in-one-wp-migration-wi
 * Domain Path: /languages
 * Network: True
 */

if ( isset( $_SERVER['HTTP_X_FORWARDED_PROTO'] ) && ( $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https' ) ) {
	$_SERVER['HTTPS'] = 'on';
}

define( 'AI1WM_PLUGIN_BASENAME', basename( dirname( __FILE__ ) ) . '/' . basename( __FILE__ ) );

define( 'AI1WM_PATH', dirname( __FILE__ ) );

define( 'AI1WM_URL', plugins_url( '', AI1WM_PLUGIN_BASENAME ) );

define( 'AI1WM_STORAGE_URL', plugins_url( 'storage', AI1WM_PLUGIN_BASENAME ) );

define( 'AI1WM_BACKUPS_URL', content_url( 'ai1wm-backups', AI1WM_PLUGIN_BASENAME ) );

define( 'AI1WM_THEMES_PATH', get_theme_root() );

require_once dirname( __FILE__ ) . DIRECTORY_SEPARATOR . 'constants.php';

require_once dirname( __FILE__ ) . DIRECTORY_SEPARATOR . 'deprecated.php';

require_once dirname( __FILE__ ) . DIRECTORY_SEPARATOR . 'functions.php';

require_once dirname( __FILE__ ) . DIRECTORY_SEPARATOR . 'exceptions.php';

require_once dirname( __FILE__ ) . DIRECTORY_SEPARATOR . 'loader.php';

$main_controller = new Ai1wm_Main_Controller();
